package com.ecommerce.conchMarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConchMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
