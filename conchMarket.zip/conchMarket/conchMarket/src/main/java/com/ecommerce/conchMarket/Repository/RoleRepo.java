package com.ecommerce.conchMarket.Repository;

public class RoleRepo {

}
