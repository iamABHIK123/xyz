import React, { useState, useEffect } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "../cssBase/Categories.css"; // Import the custom CSS

const apiEndpoint = "http://localhost:9090/products"; // Replace with your actual API endpoint
const addToCartEndpoint = "http://localhost:9090/cart/items"; // Replace with your actual Add to Cart API endpoint
const userEndpoint = "http://localhost:9090/users"; // Replace with your users API endpoint

export default function Categories() {
  const [products, setProducts] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [quantities, setQuantities] = useState({});
  const [userId, setUserId] = useState(null); // State to store userId

  useEffect(() => {
    // Fetch user's email from session storage
    const email = sessionStorage.getItem('email');
    // Fetch userId based on email
    const fetchUserId = async () => {
      try {
        const response = await axios.get(`${userEndpoint}/${email}`);
        setUserId(response.data.userId); // Assuming your response has userId
        console.log(response.data.userId);
      } catch (error) {
        console.error("Error fetching userId:", error);
      }
    };

    fetchUserId(); // Fetch userId on component mount
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(apiEndpoint);
        setProducts(response.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const handleCategoryChange = (event) => {
    setSelectedCategory(event.target.value === "All" ? null : event.target.value);
  };

  const handleAddToCart = async (product) => {
    try {
      const quantity = quantities[product.id] || 1;
      const response = await axios({
        method: 'post',
        url: addToCartEndpoint,
        data: { productId: product.id, quantity, userId }, // Include userId in the request payload
        withCredentials: true
      });
      console.log("Product added to cart:", response.data);
    } catch (error) {
      console.error("Error adding product to cart:", error);
    }
  };

  const handleIncrement = (productId) => {
    setQuantities((prevQuantities) => ({
      ...prevQuantities,
      [productId]: (prevQuantities[productId] || 1) + 1,
    }));
  };

  const handleDecrement = (productId) => {
    setQuantities((prevQuantities) => ({
      ...prevQuantities,
      [productId]: Math.max((prevQuantities[productId] || 1) - 1, 1),
    }));
  };

  const displayedProducts = selectedCategory
    ? products.filter((product) => product.category === selectedCategory)
    : products;

  return (
    <div className="container-fluid mt-4">
      <h1>Products</h1>
      <div className="row mb-3">
        <div className="col-md-12">
          <div className="btn-group">
            <select
              className="form-select"
              value={selectedCategory ? selectedCategory : "All"}
              onChange={handleCategoryChange}
            >
              <option value="All">All</option>
              {[...new Set(products.map((product) => product.category))].map((category, index) => (
                <option key={index} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-md-12 category-images">
          <div className="row">
            {displayedProducts.map((product) => (
              <div key={product.id} className="col-6 col-md-4 mb-3">
                <div className="card">
                  <img src={`../public/${product.category}/${product.imageUrl}`} className="card-img-top" alt={product.name} />
                  <div className="card-body">
                    <h5 className="card-title">{product.name}</h5>
                    <p className="card-text">Price: ${product.price.toFixed(2)}</p>
                    <div className="input-group mb-3">
                      <div className="input-group-prepend">
                        <label className="input-group-text" htmlFor={`sizeDropdown${product.id}`}>Size</label>
                      </div>
                      <select className="custom-select" id={`sizeDropdown${product.id}`}>
                        <option value="2.2">2.2</option>
                        <option value="2.4">2.4</option>
                        <option value="2.6">2.6</option>
                        <option value="2.8">2.8</option>
                        <option value="2.9">2.9</option>
                        <option value="3.0">3.0</option>
                      </select>
                    </div>
                    <div className="input-group mb-3">
                      <button className="btn btn-outline-secondary" type="button" onClick={() => handleDecrement(product.id)}>-</button>
                      <input
                        type="text"
                        value={quantities[product.id] || 1}
                        className="form-control"
                        placeholder="Quantity"
                        aria-label="Quantity"
                        readOnly
                      />
                      <button className="btn btn-outline-secondary" type="button" onClick={() => handleIncrement(product.id)}>+</button>
                    </div>
                    <button
                      className="btn btn-primary"
                      onClick={() => handleAddToCart(product)}
                    >
                      Add to Cart
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
