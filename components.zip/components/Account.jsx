import React, { useEffect, useState } from 'react';
import { Container, Typography, Box, Avatar, List, ListItem, ListItemText, ListItemAvatar, Divider, Paper, Accordion, AccordionSummary, AccordionDetails } from '@mui/material';
import OrderIcon from '@mui/icons-material/ShoppingBag';
import CouponIcon from '@mui/icons-material/LocalOffer';
import HelpIcon from '@mui/icons-material/Help';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import axios from 'axios';

export default function Account() {
  const [user, setUser] = useState(null);
  const [orderHistory, setOrderHistory] = useState([]);
  const [coupons, setCoupons] = useState([]);

  useEffect(() => {
    // Function to fetch user details based on email stored in session
    const fetchUserDetails = async () => {
      try {
        const email = sessionStorage.getItem('email'); // Assuming email is stored in session storage
        const response = await axios.get(`http://localhost:9090/users/${email}`);
        if (response.status === 200) {
          const userData = {
            name: `${response.data.firstName} ${response.data.lastName}`,
            email: response.data.email,
            profilePicture: 'https://via.placeholder.com/150', // Placeholder URL or actual profile picture URL from API
            address: '123 Main St, Springfield, USA', // Hardcoded address for now
          };
          setUser(userData); // Set the fetched user data to state
        } else {
          console.error('Failed to fetch user data');
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserDetails(); // Call the fetch function when component mounts
  }, []);

  // Dummy data for order history and coupons (as per your previous setup)
  const dummyOrderHistory = [
    { id: 1, total: 50.99 },
    { id: 2, total: 99.49 },
    { id: 3, total: 75.00 },
  ];

  const dummyCoupons = [
    { id: 1, code: 'SUMMER21', discount: 15 },
    { id: 2, code: 'WELCOME10', discount: 10 },
  ];

  // Set dummy data to state (for demonstration purposes)
  useEffect(() => {
    setOrderHistory(dummyOrderHistory);
    setCoupons(dummyCoupons);
  }, []);

  if (!user) {
    return <Typography>Loading...</Typography>;
  }

  return (
    <Container component="main" maxWidth="md" sx={{ mt: 4 }}>
      <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
        <Box display="flex" alignItems="center">
          <Avatar alt={user.name} src={user.profilePicture} sx={{ width: 56, height: 56, mr: 2 }} />
          <Box>
            <Typography variant="h5">{user.name}</Typography>
            <Typography color="textSecondary">{user.email}</Typography>
          </Box>
        </Box>
      </Paper>

      {/* Your existing accordion sections with order history, coupons, etc. */}
      {/* Replace dummy data with actual fetched data */}
      {/* Example: Order History */}
      <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
        <Accordion>
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="order-history-content"
            id="order-history-header"
          >
            <Typography variant="h6">Order History</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <List>
              {orderHistory.map(order => (
                <React.Fragment key={order.id}>
                  <ListItem>
                    <ListItemAvatar>
                      <Avatar>
                        <OrderIcon />
                      </Avatar>
                    </ListItemAvatar>
                    <ListItemText primary={`Order #${order.id}`} secondary={`Total: $${order.total}`} />
                  </ListItem>
                  <Divider variant="inset" component="li" />
                </React.Fragment>
              ))}
            </List>
          </AccordionDetails>
        </Accordion>
      </Paper>

      {/* Example: Coupons */}
      <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
        <Accordion>
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="coupons-content"
            id="coupons-header"
          >
            <Typography variant="h6">Coupons</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <List>
              {coupons.map(coupon => (
                <React.Fragment key={coupon.id}>
                  <ListItem>
                    <ListItemAvatar>
                      <Avatar>
                        <CouponIcon />
                      </Avatar>
                    </ListItemAvatar>
                    <ListItemText primary={coupon.code} secondary={`Discount: ${coupon.discount}%`} />
                  </ListItem>
                  <Divider variant="inset" component="li" />
                </React.Fragment>
              ))}
            </List>
          </AccordionDetails>
        </Accordion>
      </Paper>
    </Container>
  );
}
