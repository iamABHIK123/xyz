import React, { useState, useEffect } from 'react';
import '../cssBase/Header.css';
import { useNavigate } from 'react-router-dom';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import axios from 'axios';

const Header = () => {
  const [auth, setAuth] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Assume initial auth status from session storage or a similar mechanism
    const isAuthenticated = sessionStorage.getItem('gmail') !== null;
    setAuth(isAuthenticated);
  }, []);

  const handleAuthToggle = async () => {
    if (auth) {
      try {
        await axios.post('http://localhost:9090/logout', {}, { withCredentials: true });
        sessionStorage.removeItem('gmail'); // Remove the gmail item from session storage
        setAuth(false);
        navigate('/'); // Navigate to home or another appropriate route after logout
      } catch (error) {
        console.error('Logout failed', error);
      }
    } else {
      navigate('/login');
      // Assuming the login process will set the session storage item "gmail"
      // The auth state will be set to true in useEffect after login
    }
  };

  return (
    <header className="header">
      <div className="header-top">
        <span className="header-title">Shri Radha Shankha Mahal</span>
      </div>
      <div className="header-bottom">
        <input type="text" className="header-search-bar" placeholder="Search..." />
        <button className="header-login-button" onClick={handleAuthToggle}>
          {auth ? 'Logout' : 'Login'}
        </button>
        <div className="header-cart-icon">
          <ShoppingCartIcon />
        </div>
      </div>
    </header>
  );
};

export default Header;
