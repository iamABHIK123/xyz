import React, { useState, useEffect } from "react";
import axios from "axios";

const cartItemsEndpoint = "http://localhost:9090/cart/items"; // Replace with your actual endpoint

const Cart = () => {
  const [cartItems, setCartItems] = useState([]);
  const [productsDetails, setProductsDetails] = useState([]);
  const [subtotal, setSubtotal] = useState(0);
  const deliveryCharges = 5; // Example delivery charges, replace with your actual logic
  const [totalAmount, setTotalAmount] = useState(0);

  useEffect(() => {
    const fetchCartItems = async () => {
      try {
        const response = await axios.get(cartItemsEndpoint, { withCredentials: true });
        setCartItems(response.data);
      } catch (error) {
        console.error("Error fetching cart items:", error);
      }
    };

    fetchCartItems();
  }, []);

  useEffect(() => {
    const fetchProductDetails = async () => {
      try {
        const productIds = cartItems.map((item) => item.productId);

        const productDetailsPromises = productIds.map(async (productId) => {
          const response = await axios.get(`http://localhost:9090/products/${productId}`);
          return response.data;
        });

        const productDetails = await Promise.all(productDetailsPromises);
        setProductsDetails(productDetails);

        // Calculate subtotal and total amount
        let subtotalAmount = 0;
        productDetails.forEach((product, index) => {
          subtotalAmount += product.price * cartItems[index].quantity;
        });

        setSubtotal(subtotalAmount);
        setTotalAmount(subtotalAmount + deliveryCharges);
      } catch (error) {
        console.error("Error fetching product details:", error);
      }
    };

    if (cartItems.length > 0) {
      fetchProductDetails();
    }
  }, [cartItems]);

  const handleUpdateQuantity = async (productId, quantity) => {
    if (quantity < 1) {
      return; // Prevent updating the quantity to less than 1
    }
    try {
      const response = await axios.put(
        `${cartItemsEndpoint}/${productId}`,
        { quantity },
        { withCredentials: true }
      );
      setCartItems(response.data);
    } catch (error) {
      console.error("Error updating cart item quantity:", error);
    }
  };

  const handleRemoveItem = async (productId) => {
    try {
      const response = await axios.delete(
        `${cartItemsEndpoint}/${productId}`,
        { withCredentials: true }
      );
      setCartItems(response.data);
    } catch (error) {
      console.error("Error removing cart item:", error);
    }
  };

  return (
    <div className="container mt-4">
      <h1>Your Cart</h1>
      {sessionStorage.getItem("email")== null && productsDetails.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <div>
          <div className="row">
            {productsDetails.map((product, index) => (
              <div key={product.id} className="col-12 col-md-6 mb-3">
                <div className="card">
                  <img
                    src={`../public/${product.category}/${product.imageUrl}`}
                    className="card-img-top"
                    alt={product.name}
                  />
                  <div className="card-body">
                    <h5 className="card-title">{product.name}</h5>
                    <p className="card-text">Price: ${product.price.toFixed(2)}</p>
                    <p className="card-text">Description: {product.description}</p>
                    <p className="card-text">Size: {product.size}</p>
                    <div className="input-group mb-3">
                      <button
                        className="btn btn-outline-secondary"
                        type="button"
                        onClick={() => handleUpdateQuantity(product.id, cartItems[index].quantity - 1)}
                      >
                        -
                      </button>
                      <input
                        type="text"
                        className="form-control"
                        value={cartItems[index].quantity}
                        readOnly
                      />
                      <button
                        className="btn btn-outline-secondary"
                        type="button"
                        onClick={() => handleUpdateQuantity(product.id, cartItems[index].quantity + 1)}
                      >
                        +
                      </button>
                    </div>
                    <button
                      className="btn btn-danger mb-2"
                      onClick={() => handleRemoveItem(product.id)}
                    >
                      Remove
                    </button>
                    <p className="card-text">Subtotal: ${product.price * cartItems[index].quantity}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="row mt-3">
            <div className="col-12">
              <p className="text-end">
                Subtotal: ${subtotal.toFixed(2)}
                <br />
                Delivery Charges: ${deliveryCharges.toFixed(2)}
                <br />
                Total Amount: ${totalAmount.toFixed(2)}
              </p>
              <button className="btn btn-primary float-end">Checkout</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
